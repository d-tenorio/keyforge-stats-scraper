To use keyforge_stats_scraper_exe, make sure the file kf_deck_links consists of links 
(any combination of keyforge-compendium, keyforgegame, or decksofkeyforge), 
one per line with no extra spaces or characters added. The sample file shows a properly formatted example.

Then, double click on the executable file. If the program executes successfully, the output should be saved to a
file named 'deck_info_output.csv', with debugging info saved to 'kss_debug.txt'.

Any questions? Contact the repository owner at dtenorio.work@gmail.com.